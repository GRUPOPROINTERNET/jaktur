# jaktur

Grupo Jaktur

Maquetador: Harold Caraballo

Maquetador URI: https://Publinet.net.ve

Version: 1.0.0

Description: Maquetación Web con Bootstrap 4.4.1 , HTML5, Sass, Javascript

Text Domain: base

Tags: Franquicias, negocios

Theme URI:

Fecha: 27-04-2020
